package com.example.k2025_03_25_basic_radio

import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
//import com.example.k2025_03_25_basic_radio.ui.theme.Theme
import coil.compose.AsyncImage
import com.example.k2025_03_25_basic_radio.model.RadioViewModel
import com.example.k2025_03_25_basic_radio.model.RadioStates
import com.example.k2025_03_25_basic_radio.model.RadioStation
import com.example.k2025_03_25_basic_radio.model.RadioStationsManager
import com.example.k2025_03_25_basic_radio.service.RadioService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.res.Resources
import android.os.*
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
                RadioScreen()
        }
    }

    private var mediaPlayer: MediaPlayer? = null
    private var radioIsSetUp: Boolean = false
    private var currentRadio: String? = null

    @Composable
    fun RadioScreen(viewModel: RadioViewModel = viewModel()) {
        val stations by viewModel.stations.collectAsState()
        var volume by remember { mutableStateOf(1f) }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxSize()
        ) {
            Text(text = "Radio!!")

            LazyColumn(
                modifier = Modifier.weight(1f)  // makes sure it doesn't squish UI
            ) {
                items(stations) { station ->
                    RadioStationItem(station)
                }
            }

            Text(text = "Volume", modifier = Modifier.padding(16.dp))
            Slider(
                value = volume,
                onValueChange = {
                    volume = it
                    setVolume(volume)
                },
                valueRange = 0f..1f,
                modifier = Modifier.padding(horizontal = 32.dp)
            )

            Row(modifier = Modifier.padding(16.dp)) {
                Button(onClick = { startRadio() }) {
                    Log.i("RFR", "Radio start")
                    Text(text = "Start Radio")
                }
                Spacer(modifier = Modifier.width(16.dp))
                Button(onClick = { stopRadio() }) {
                    Log.i("RFR", "Radio stop")
                    Text(text = "Stop Radio")
                }
            }
        }
    }

    @Composable
    fun RadioStationItem(station: RadioStation) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .clickable { switchRadio(station.url) },
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(
                model = station.imageurl,
                contentDescription = station.name,
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = station.name,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            )
        }
    }

    private fun switchRadio(url: String) {
        Log.i("RFR", "Switching to: $url")
        stopRadio()
        setUpRadio(url)
        currentRadio = url // for testing purposes
    }

    private fun startRadio() {
        if (radioIsSetUp) {
            Log.i("RFR", "Radio is starting")
            mediaPlayer?.start()
        }
    }

    private fun stopRadio() {
        if (radioIsSetUp) {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
            radioIsSetUp = false
        }
    }

    private fun setUpRadio(url: String) {
        if (radioIsSetUp == false) {
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(url)
                prepareAsync()
                setOnPreparedListener { start()}
            }
            radioIsSetUp = true // updating variable
        }
    }

    private fun setVolume(volume: Float) {
        mediaPlayer?.setVolume(volume, volume)
    }

}

