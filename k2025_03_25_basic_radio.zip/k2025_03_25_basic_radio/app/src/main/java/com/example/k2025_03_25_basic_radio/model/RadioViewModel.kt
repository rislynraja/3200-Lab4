package com.example.k2025_03_25_basic_radio.model

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import com.example.k2025_03_25_basic_radio.model.RadioStation
import com.example.k2025_03_25_basic_radio.model.RadioStationsManager

class RadioViewModel : ViewModel() {
    private val manager = RadioStationsManager()

    private val _stations = MutableStateFlow<List<RadioStation>>(emptyList())
    val stations: StateFlow<List<RadioStation>> get() = _stations

    init {
        _stations.value = List(manager.getNumberOfRadioStations()) { index ->
            manager.getStation(index)
        }
    }
}