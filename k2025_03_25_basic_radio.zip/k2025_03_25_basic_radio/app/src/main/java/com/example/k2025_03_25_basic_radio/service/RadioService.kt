package com.example.k2025_03_25_basic_radio.service

import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.IBinder
import android.os.Messenger
import android.util.Log
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.k2025_03_25_basic_radio.model.RadioViewModel
import com.example.k2025_03_25_basic_radio.model.RadioStates
import com.example.k2025_03_25_basic_radio.model.RadioStation
import com.example.k2025_03_25_basic_radio.model.RadioStationsManager
import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.os.*
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class RadioService : Service() {

    private lateinit var mMessenger: Messenger
    private var mediaPlayer: MediaPlayer? = null
    /**
     * Handler of incoming messages from clients.
     */

    val handler = Handler(Looper.getMainLooper()) { msg ->
        when (msg.what) {
            RadioStates.SETUP_RADIO.stateInteger -> {
                val url = msg.data.getString("url")
                Log.i("Service", "Setting up radio with URL: $url")
                url?.let {
                    setUpRadio(it)
                }
                true
            }
            RadioStates.PREPARE_ASYNC.stateInteger -> {
                Log.i("Service ", RadioStates.PREPARE_ASYNC.stateInteger.toString())
                mediaPlayer?.prepareAsync()
                true
            }
            RadioStates.START.stateInteger -> {
                Log.i("Service ", RadioStates.START.stateInteger.toString())
                if (mediaPlayer != null && !mediaPlayer!!.isPlaying) {
                    mediaPlayer?.start()
                } else {
                    Log.w("Service", "MediaPlayer is not prepared or already playing")
                }
                true
            }
            RadioStates.STOP.stateInteger -> {
                Log.i("Service ", RadioStates.STOP.stateInteger.toString())
                mediaPlayer?.let {
                    if (it.isPlaying) {
                        it.stop()
                    }
                }
                true
            }
            RadioStates.DESTROY.stateInteger -> {
                Log.i("Service ", RadioStates.DESTROY.stateInteger.toString())
                mediaPlayer?.apply {
                    stop()
                    release()
                }
                mediaPlayer = null
                true
            }
            else -> {
                Log.i("Service ", RadioStates.START.stateInteger.toString())
                true
            }
        }
    }




    /**
     * When binding to the service, we return an interface to our messenger
     * for sending messages to the service.
     */
    override fun onBind(intent: Intent): IBinder? {
        Toast.makeText(applicationContext, "binding", Toast.LENGTH_SHORT).show()
        mMessenger = Messenger(handler)
        return mMessenger.binder
    }

    private fun setUpRadio(myUrl: String) {
        mediaPlayer?.release()
        mediaPlayer = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            setDataSource(myUrl)
            prepareAsync()
            setOnPreparedListener {
                start()
            }
        }
    }


}

