package com.example.k2025_03_25_basic_radio.model

data class RadioStation(val name: String, val url: String, val imageurl: String)