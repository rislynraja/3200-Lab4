package com.example.k2025_03_25_basic_radio.model

class RadioStationsManager {
    private val allRadioStations = listOf(
        RadioStation("UConn Radio","http://stream.whus.org:8000/whusfm","https://brand.uconn.edu/wp-content/uploads/sites/14/2019/08/husky-logo-lockup-circleR.jpg"),
        RadioStation("Bolton Radio","http://radio.canstream.co.uk:8000/live.mp3","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTFq4_cp2e8zCA2askoa7y-uALw8ruzoLC-0Q&s"),
        RadioStation("Jazz Radio","https://icecast.walmradio.com:8443/jazz","https://i.pinimg.com/736x/00/6f/e7/006fe7f785c991102866b859a4b6be7e.jpg"),
        RadioStation("80s Radio","https://0n-80s.radionetz.de/0n-80s.mp3","https://img.freepik.com/premium-vector/retro-vibes-revival-celebrate-classic-80s-music-with-bold-vibrant-design_585146-1166.jpg"),
        RadioStation("Pop Radio","https://adhandler.kissfmradio.cires21.com/get_link?url=https://bbkissfm.kissfmradio.cires21.com/bbkissfm.mp3","https://static.vecteezy.com/system/resources/thumbnails/007/379/506/small_2x/pop-music-vintage-3d-lettering-retro-bold-font-typeface-pop-art-stylized-text-old-school-style-neon-light-letters-90s-80s-poster-banner-dark-violet-color-background-vector.jpg"),
        RadioStation("Kpop Radio","https://antares.dribbcast.com/proxy/kpop?mp=/s","https://img.freepik.com/free-vector/k-pop-music-concept_52683-43966.jpg"),
        RadioStation("Country Radio","https://0n-country.radionetz.de/0n-country.mp3","https://t4.ftcdn.net/jpg/03/15/99/71/360_F_315997124_HKjCX2F8A3ln486Doc7Md3K0ulaHJvdQ.jpg"),
        RadioStation("Rock Radio","https://0n-classicrock.radionetz.de/0n-classicrock.mp3","https://ak1.ostkcdn.com/images/products/9075649/Rock-Music-Logo-Decor-Vinyl-Wall-Art-L16267517.jpg"),
        RadioStation("Hiphop Radio","https://breakz-2012-high.rautemusik.fm/?ref=radiobrowser-top100-clubcharts","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTkwgznJfgCqcC8pCCuw1PXJnnAyNjlrLFWgQ&s"),
        RadioStation("Metal Radio","https://0n-heavymetal.radionetz.de/0n-heavymetal.mp3","https://www.shutterstock.com/image-vector/musical-drums-set-playing-silhouette-600nw-2475490693.jpg")
    )
    private var whichStation: Int = 0

    fun getStation() : RadioStation {
        return allRadioStations[whichStation]
    }

    fun getStation(whichStation: Int) : RadioStation {
        return allRadioStations[whichStation % allRadioStations.size]
    }

    fun nextStation() {
        whichStation = (whichStation + 1) % allRadioStations.size
    }

    fun getNumberOfRadioStations() : Int {
        return allRadioStations.size
    }

}
